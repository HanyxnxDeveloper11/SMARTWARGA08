# RT 08 SMART

Android app project generated with Android Studio / Google AI Studio.

## Build APK on GitHub

1. Upload this project to a GitHub repository.
2. Push to the `main` branch, or open **Actions → Build Android APK → Run workflow**.
3. When the workflow finishes, open the workflow run.
4. Under **Artifacts**, download `rt-08-smart-debug-apk`.
5. Extract the ZIP artifact to get the `.apk` file.

The workflow builds the debug APK and does not require a release keystore. Do not commit `.env`, API keys, or other secrets.
