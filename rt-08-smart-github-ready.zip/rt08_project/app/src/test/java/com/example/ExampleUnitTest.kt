package com.example

import com.example.util.Formatters
import com.example.util.SecurityUtils
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testPasswordHashingAndVerification() {
    val rawPassword = "admin123"
    val hash = SecurityUtils.hashPassword(rawPassword)
    assertNotEquals(rawPassword, hash)
    assertTrue(SecurityUtils.verifyPassword("admin123", hash))
    assertFalse(SecurityUtils.verifyPassword("wrongpass", hash))
  }

  @Test
  fun testFinanceBalanceFormula() {
    val initialBalance = 0L
    val totalIncome = 13800000L
    val totalExpense = 2800000L
    val finalBalance = initialBalance + totalIncome - totalExpense
    assertEquals(11000000L, finalBalance)
  }

  @Test
  fun testFormatRupiah() {
    val formatted = Formatters.formatRupiah(5000000L)
    assertTrue(formatted.contains("5.000.000"))
  }

  @Test
  fun testNewContactsAndPengurus() {
    val pakBudiPhone = "08130798892"
    val buIkaPhone = "087788141935"
    val pamanYaniPhone = "08158223509"
    val polisi = "110"
    val damkar = "112"

    assertEquals(11, pakBudiPhone.length)
    assertEquals(12, buIkaPhone.length)
    assertEquals(11, pamanYaniPhone.length)
    assertEquals("110", polisi)
    assertEquals("112", damkar)
  }
}

