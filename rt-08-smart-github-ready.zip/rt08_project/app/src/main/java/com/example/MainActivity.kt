package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.UserRole
import com.example.ui.ActiveModal
import com.example.ui.NavigationTab
import com.example.ui.RtSmartViewModel
import com.example.ui.screens.AboutRtDialog
import com.example.ui.screens.AddAgendaDialog
import com.example.ui.screens.AddAnnouncementDialog
import com.example.ui.screens.AddTransactionDialog
import com.example.ui.screens.AddUserDialog
import com.example.ui.screens.AdminDashboardContent
import com.example.ui.screens.AgendaScreen
import com.example.ui.screens.AnnouncementsScreen
import com.example.ui.screens.AuditLogContent
import com.example.ui.screens.ContactListDialog
import com.example.ui.screens.FinanceScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LoginDialog
import com.example.ui.screens.MoreScreen
import com.example.ui.screens.OfficialsListDialog
import com.example.ui.screens.PortalWelcomeScreen
import com.example.ui.screens.ReportDetailDialog
import com.example.ui.screens.ResetPasswordDialog
import com.example.ui.screens.ServicesListDialog
import com.example.ui.screens.SubmitLetterDialog
import com.example.ui.screens.SubmitReportDialog
import com.example.ui.screens.UserManagementContent
import com.example.ui.theme.CivicGreenPrimary
import com.example.ui.theme.ForestTealSecondary
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                RtSmartApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RtSmartApp(viewModel: RtSmartViewModel = viewModel()) {
    val context = LocalContext.current
    val session by viewModel.session.collectAsStateWithLifecycle()
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val activeModal by viewModel.activeModal.collectAsStateWithLifecycle()
    val userMessage by viewModel.userMessage.collectAsStateWithLifecycle()

    val transactions by viewModel.allTransactions.collectAsStateWithLifecycle()
    val publicTransactions by viewModel.publicTransactions.collectAsStateWithLifecycle()
    val summary by viewModel.financialSummary.collectAsStateWithLifecycle()
    val announcements by viewModel.allAnnouncements.collectAsStateWithLifecycle()
    val agendas by viewModel.allAgendas.collectAsStateWithLifecycle()
    val reports by viewModel.allReports.collectAsStateWithLifecycle()
    val letters by viewModel.allLetters.collectAsStateWithLifecycle()
    val users by viewModel.allUsers.collectAsStateWithLifecycle()
    val auditLogs by viewModel.auditLogs.collectAsStateWithLifecycle()

    var loginErrorMessage by remember { mutableStateOf<String?>(null) }
    var initialTxType by remember { mutableStateOf("PEMASUKAN") }

    // User message toast
    LaunchedEffect(userMessage) {
        userMessage?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            viewModel.clearUserMessage()
        }
    }

    // Hardware Back button handling
    BackHandler(enabled = true) {
        when {
            activeModal != null -> viewModel.closeModal()
            currentTab != NavigationTab.BERANDA -> viewModel.selectTab(NavigationTab.BERANDA)
            session != null -> viewModel.logout()
        }
    }

    // If session is null: show Portal Utama
    if (session == null) {
        PortalWelcomeScreen(
            onSelectAdminLogin = {
                loginErrorMessage = null
                viewModel.openModal(ActiveModal.Login)
            },
            onSelectWargaMode = {
                viewModel.enterAsGuest()
            }
        )
    } else {
        // Authenticated or Guest in Portal
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "RT 08 SMART",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                            Text(
                                text = "Jl. Giring Giring 1 • RT 08/10",
                                fontSize = 11.sp,
                                color = Color(0xFFE8F5E9)
                            )
                        }
                    },
                    actions = {
                        // Role badge chip
                        Surface(
                            color = if (session?.isGuest == true) Color.White.copy(alpha = 0.2f) else Color(0xFFFFD54F).copy(alpha = 0.3f),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.padding(end = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (session?.isGuest == true) "Warga (View Only)" else (session?.role?.label ?: "Pengurus"),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }

                        // Logout / Switch button
                        IconButton(
                            onClick = { viewModel.logout() },
                            modifier = Modifier.testTag("topbar_logout_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Logout,
                                contentDescription = "Keluar / Ganti Akun",
                                tint = Color.White
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = CivicGreenPrimary,
                        titleContentColor = Color.White
                    )
                )
            },
            bottomBar = {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp
                ) {
                    val tabs = listOf(
                        Triple(NavigationTab.BERANDA, Icons.Default.Home, "Beranda"),
                        Triple(NavigationTab.KEUANGAN, Icons.Default.AccountBalanceWallet, "Keuangan"),
                        Triple(NavigationTab.PENGUMUMAN, Icons.Default.Campaign, "Pengumuman"),
                        Triple(NavigationTab.AGENDA, Icons.Default.Event, "Agenda"),
                        Triple(NavigationTab.LAINNYA, Icons.Default.Menu, "Lainnya")
                    )

                    tabs.forEach { (tab, icon, label) ->
                        val selected = currentTab == tab
                        NavigationBarItem(
                            selected = selected,
                            onClick = { viewModel.selectTab(tab) },
                            icon = {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = label,
                                    modifier = Modifier.size(22.dp)
                                )
                            },
                            label = {
                                Text(
                                    text = label,
                                    fontSize = 11.sp,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = CivicGreenPrimary,
                                selectedTextColor = CivicGreenPrimary,
                                indicatorColor = CivicGreenPrimary.copy(alpha = 0.15f)
                            ),
                            modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (currentTab) {
                    NavigationTab.BERANDA -> {
                        HomeScreen(
                            session = session,
                            financialSummary = summary,
                            announcements = announcements,
                            agendas = agendas,
                            reports = reports,
                            onNavigateTab = { viewModel.selectTab(it) },
                            onOpenModal = { viewModel.openModal(it) }
                        )
                    }
                    NavigationTab.KEUANGAN -> {
                        FinanceScreen(
                            session = session,
                            summary = summary,
                            transactions = if (session?.isGuest == true) publicTransactions else transactions,
                            canManageFinance = viewModel.canManageFinance(),
                            onOpenAddTransaction = {
                                initialTxType = "PEMASUKAN"
                                viewModel.openModal(ActiveModal.AddTransaction)
                            },
                            onDeleteTransaction = { viewModel.deleteTransaction(it) }
                        )
                    }
                    NavigationTab.PENGUMUMAN -> {
                        AnnouncementsScreen(
                            announcements = announcements,
                            canManageAnnouncements = viewModel.canManageAnnouncements(),
                            onOpenAddAnnouncement = { viewModel.openModal(ActiveModal.AddAnnouncement) },
                            onDeleteAnnouncement = { viewModel.deleteAnnouncement(it) }
                        )
                    }
                    NavigationTab.AGENDA -> {
                        AgendaScreen(
                            agendas = agendas,
                            canManageAgendas = viewModel.canManageAnnouncements(),
                            onOpenAddAgenda = { viewModel.openModal(ActiveModal.AddAgenda) },
                            onDeleteAgenda = { viewModel.deleteAgenda(it) }
                        )
                    }
                    NavigationTab.LAINNYA -> {
                        MoreScreen(
                            session = session,
                            onOpenModal = { viewModel.openModal(it) },
                            onLogout = { viewModel.logout() },
                            onSwitchToLogin = {
                                loginErrorMessage = null
                                viewModel.openModal(ActiveModal.Login)
                            }
                        )
                    }
                }
            }
        }
    }

    // Modal dialogs
    when (val modal = activeModal) {
        is ActiveModal.Login -> {
            LoginDialog(
                onDismiss = { viewModel.closeModal() },
                onLoginSubmit = { u, p ->
                    viewModel.login(u, p) { success, msg ->
                        if (!success) {
                            loginErrorMessage = msg
                        }
                    }
                },
                errorMessage = loginErrorMessage
            )
        }
        is ActiveModal.AddTransaction -> {
            AddTransactionDialog(
                initialType = initialTxType,
                onDismiss = { viewModel.closeModal() },
                onSubmit = { title, cat, amt, type, note, pub ->
                    viewModel.addTransaction(title, cat, amt, type, note, pub)
                }
            )
        }
        is ActiveModal.AddAnnouncement -> {
            AddAnnouncementDialog(
                onDismiss = { viewModel.closeModal() },
                onSubmit = { title, content, cat, pin ->
                    viewModel.addAnnouncement(title, content, cat, pin)
                }
            )
        }
        is ActiveModal.AddAgenda -> {
            AddAgendaDialog(
                onDismiss = { viewModel.closeModal() },
                onSubmit = { title, desc, date, time, loc, coord ->
                    viewModel.addAgenda(title, desc, date, time, loc, coord)
                }
            )
        }
        is ActiveModal.SubmitReport -> {
            SubmitReportDialog(
                onDismiss = { viewModel.closeModal() },
                onSubmit = { name, phone, cat, title, desc, loc ->
                    viewModel.submitReport(name, phone, cat, title, desc, loc)
                }
            )
        }
        is ActiveModal.ReportDetail -> {
            ReportDetailDialog(
                report = modal.report,
                isOfficial = viewModel.isOfficial(),
                onDismiss = { viewModel.closeModal() },
                onUpdateStatus = { rep, st, note ->
                    viewModel.updateReportStatus(rep, st, note)
                }
            )
        }
        is ActiveModal.ServicesList -> {
            ServicesListDialog(
                letters = letters,
                onDismiss = { viewModel.closeModal() },
                onOpenSubmitLetter = { viewModel.openModal(ActiveModal.SubmitLetter) }
            )
        }
        is ActiveModal.SubmitLetter -> {
            SubmitLetterDialog(
                onDismiss = { viewModel.closeModal() },
                onSubmit = { name, nik, type, purpose, phone, addr ->
                    viewModel.submitLetterRequest(name, nik, type, purpose, phone, addr)
                }
            )
        }
        is ActiveModal.ContactList -> {
            ContactListDialog(onDismiss = { viewModel.closeModal() })
        }
        is ActiveModal.OfficialsList -> {
            OfficialsListDialog(onDismiss = { viewModel.closeModal() })
        }
        is ActiveModal.AboutRt -> {
            AboutRtDialog(onDismiss = { viewModel.closeModal() })
        }
        is ActiveModal.AdminDashboard -> {
            AdminDashboardContent(
                session = session,
                summary = summary,
                announcementsCount = announcements.size,
                agendasCount = agendas.size,
                reportsCount = reports.size,
                onClose = { viewModel.closeModal() },
                onOpenModal = { viewModel.openModal(it) },
                onOpenAddTransactionIncome = {
                    initialTxType = "PEMASUKAN"
                    viewModel.openModal(ActiveModal.AddTransaction)
                },
                onOpenAddTransactionExpense = {
                    initialTxType = "PENGELUARAN"
                    viewModel.openModal(ActiveModal.AddTransaction)
                }
            )
        }
        is ActiveModal.ManageUsers -> {
            UserManagementContent(
                users = users,
                currentUser = session?.user,
                onClose = { viewModel.closeModal() },
                onOpenAddUser = { viewModel.openModal(ActiveModal.AddUser) },
                onToggleActive = { viewModel.toggleUserActiveStatus(it) },
                onResetPassword = { viewModel.openModal(ActiveModal.ResetPassword(it)) }
            )
        }
        is ActiveModal.AddUser -> {
            AddUserDialog(
                onDismiss = { viewModel.closeModal() },
                onSubmit = { name, user, pass, pos, role ->
                    viewModel.createUser(name, user, pass, pos, role)
                }
            )
        }
        is ActiveModal.ResetPassword -> {
            ResetPasswordDialog(
                user = modal.targetUser,
                onDismiss = { viewModel.closeModal() },
                onSubmit = { newPass ->
                    viewModel.resetUserPassword(modal.targetUser, newPass)
                }
            )
        }
        is ActiveModal.AuditLog -> {
            AuditLogContent(
                logs = auditLogs,
                onClose = { viewModel.closeModal() }
            )
        }
        is ActiveModal.LetterDetail -> {
            // Handled within ServicesListDialog or closes
            viewModel.closeModal()
        }
        null -> { /* No modal */ }
    }
}
